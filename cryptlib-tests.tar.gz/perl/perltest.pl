#############################################################################
#
# This file is part of the cryptlib test package
# File:      perltest.pl
# Version  : 1.0
# License  : BSD
#
#
# Copyright (c) 2016-2019
#	Ralf Senderek, Ireland.  All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 3. All advertising materials mentioning features or use of this software
#    must display the following acknowledgement:
#	   This product includes software developed by Ralf Senderek.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
# OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
# OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.
#############################################################################



use lib "/usr/lib64/perl5";
use PerlCryptLib qw(:all);
use MIME::Base64;

my $envelope = CRYPT_ENVELOPE;

if ( cryptInit() == CRYPT_OK ) {
     if ( cryptCreateEnvelope($envelope, 
                              CRYPT_UNUSED, 
                              CRYPT_FORMAT_CRYPTLIB) == CRYPT_OK ) {
       print "Cryptlib : performing basic hash test in Perl.\n";
       my $hashContext = CRYPT_CONTEXT;
       my $cryptUser = CRYPT_UNUSED;
       my $max = 500;
       my $buffer = 'cryptlib';
       my $hash = "";
       my $hashName = "";
       my $hashLength = 0;
       my $numBytes = 0;

       cryptCreateContext( $hashContext, $cryptUser, CRYPT_ALGO_SHA1 );

       cryptEncrypt( $hashContext, $buffer, 8 );
       cryptEncrypt( $hashContext, $buffer, 0 );
       
       cryptGetAttributeString( $hashContext, CRYPT_CTXINFO_HASHVALUE, $hash, $hashLength );
       cryptGetAttributeString( $hashContext, CRYPT_CTXINFO_NAME_ALGO, $hashName, $numBytes); 
       
       print "\n";
       printf("Hash algo: %s \n",$hashName);
       printf("Data     : %s \n","cryptlib");
       printf("Hash     : %s \n",$hash);
       printf("base64   : %s \n",encode_base64($hash));
       my $hexhash = unpack("H*",$hash);
       print "hex      : ";
       print $hexhash;
       print "\n";
       cryptDestroyContext($hashContext);
       cryptDestroyEnvelope($envelope);
     }
     cryptEnd();
}
