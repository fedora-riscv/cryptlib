JAVA development
================

Use the CLASSPATH environment variable

export CLASSPATH=/usr/lib/java/cryptlib.jar:.

and:

  javac encrypt.java ; java encrypt



OR



Copy the cryptlib.jar file into your working directory.
  cp /usr/lib/java/cryptlib.jar .

Plain text test data can be stored in the file ./infile
Encrypted output will be stored in ./outfile

Compile a Java program:
  javac -cp cryptlib.jar encrypt.java 


Run the compiled class:
  java -cp cryptlib.jar:. encrypt

