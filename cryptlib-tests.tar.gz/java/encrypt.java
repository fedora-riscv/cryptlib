/*
*
* This file is part of the cryptlib test package
* File: encrypt.java
* Version  : 1.0
* License  : BSD
*
*
* Copyright (c) 2016-2021
*	Ralf Senderek, Ireland.  All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
* 1. Redistributions of source code must retain the above copyright
*    notice, this list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright
*    notice, this list of conditions and the following disclaimer in the
*    documentation and/or other materials provided with the distribution.
* 3. All advertising materials mentioning features or use of this software
*    must display the following acknowledgement:
*	   This product includes software developed by Ralf Senderek.
*
* THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
* OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
* SUCH DAMAGE.
*
*****************************************************/

import cryptlib.*;

import java.io.*;
import java.nio.file.*;
import java.nio.charset.*;

class encrypt
{
     public static void printBytes(byte[] BA) {
          StringBuilder str = new StringBuilder();
          for(int i = 0; i < BA.length; i++){
               str.append(String.format("%s",(char)  BA[i]));
          }
          System.out.println(str.toString());
     }

     public static String toHex(byte[] BA) {
         StringBuilder str = new StringBuilder();
         //byte[] BA = IN.getBytes(Charset.forName("ISO-8859-1"));
         for(int i = 0; i < BA.length; i++){
               str.append(String.format("%x",(byte)  BA[i]));
         }
         return str.toString();
     }

     public static void writeToFile(byte[] data) {
          try {
     	       FileOutputStream stream = new FileOutputStream("./outfile",false);
	       stream.write(data);
	       stream.close();
	  } catch(IOException e) {
	       System.err.println("Error writing to outfile.");
          }
     }

     public static void main( String[] args )
     {

          byte[] input   = new byte[500];
          byte[] output  = new byte[500];
	  String key = "rumpelstielskin";
          int bytescopied = 0;
	  int bytesout = 0;

	  Charset DefaultCharset = Charset.defaultCharset();
	  try{
               input = Files.readAllBytes(Paths.get("./infile"));
	  } catch(IOException e) { 
	       input = "Cryptlib 3.4.6".getBytes();
	  }
          
	  System.load( "/usr/lib64/libcl.so" );
          // cryptlib library name
          try
          {
                crypt.Init();

	        System.out.println("Cryptlib : performing PGP envelope encryption in Java.\n");
                System.out.println("reading file content:\n");
		printBytes(input);
	        
		int cryptEnvelope = crypt.CreateEnvelope( crypt.UNUSED, crypt.FORMAT_PGP );
	        crypt.SetAttributeString( cryptEnvelope, crypt.ENVINFO_PASSWORD, key );
		crypt.SetAttribute( cryptEnvelope, crypt.ENVINFO_DATASIZE, input.length );
                bytescopied = crypt.PushData( cryptEnvelope, input);
		System.out.print(bytescopied);
		System.out.println(" bytes in");
	        crypt.FlushData( cryptEnvelope );	
	        bytesout = crypt.PopData( cryptEnvelope, output , 500); 
		System.out.print(bytesout);
		System.out.println(" bytes out");
		//printBytes(output);
	        System.out.println(toHex(output));	
		writeToFile(output);
		
	        crypt.DestroyEnvelope( cryptEnvelope );
   	        crypt.End();
           }
           catch( CryptException e )
           {
                // cryptlib returned an error
                e.printStackTrace();
           }
     }
};
